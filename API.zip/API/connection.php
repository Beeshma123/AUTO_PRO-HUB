<?php
$_cono=mysqli_connect("localhost","root","vehicles_portal");
?>